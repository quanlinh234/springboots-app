package com.thong.databaseMysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyDemoFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
