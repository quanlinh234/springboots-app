package com.thong.databaseMysql.repositories;

import com.thong.databaseMysql.TestDataUtil;
import com.thong.databaseMysql.domain.entities.AuthorEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class UserRepositoryIntegrationTests {



    private  AuthorRepository underTest;

    @Autowired
    public UserRepositoryIntegrationTests(AuthorRepository authorDao)
    {
        this.underTest = authorDao;
    }
    @Test
    public void testThatAuthorCanBeCreatedAndRecalled()
    {
        AuthorEntity authorEntity = TestDataUtil.getAuthorA();
        underTest.save(authorEntity);
        Optional<AuthorEntity> result = underTest.findById(authorEntity.getId());
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(authorEntity);
    }
    @Test
    public void testThatAuthorCanBeFoundMany()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        AuthorEntity authorEntityB = TestDataUtil.getAuthorB();
        AuthorEntity authorEntityC = TestDataUtil.getAuthorC();
        underTest.save(authorEntityA);
        underTest.save(authorEntityB);
        underTest.save(authorEntityC);
        Iterable<AuthorEntity> result =  underTest.findAll();
        assertThat(result).hasSize(3).containsExactly(authorEntityA, authorEntityB, authorEntityC);
    }
    @Test
    public void testThatAuthorCanBeUpdated()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        underTest.save(authorEntityA);
       authorEntityA.setName("Van Thong");
       authorEntityA.setAge(25);
        underTest.save(authorEntityA);
        Optional<AuthorEntity> result = underTest.findById(authorEntityA.getId());
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(authorEntityA);
    }
    @Test
    public void testThatBookCanBeDeleted()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        AuthorEntity authorEntityB = TestDataUtil.getAuthorB();
        underTest.save(authorEntityA);
        underTest.save(authorEntityB);
        underTest.delete(authorEntityA);
        Optional<AuthorEntity> result = underTest.findById(authorEntityA.getId());
        assertThat(result).isEmpty();
    }
}
