package com.thong.databaseMysql;

import com.thong.databaseMysql.domain.dto.AuthorDto;
import com.thong.databaseMysql.domain.dto.BookDto;
import com.thong.databaseMysql.domain.entities.AuthorEntity;
import com.thong.databaseMysql.domain.entities.BookEntity;

public class TestDataUtil {
    public static AuthorEntity getAuthorA() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(1L)
                .name("anhnguyen")
                .age(37)
                .build();
        return authorEntity;
    }
    public static AuthorEntity getAuthorB() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(2L)
                .name("thongtran")
                .age(37)
                .build();
        return authorEntity;
    }
    public static AuthorEntity getAuthorC() {
        AuthorEntity authorEntity = AuthorEntity.builder()
                .id(3L)
                .name("nganvo")
                .age(37)
                .build();
        return authorEntity;
    }
    public static BookDto getBookDtoA(final AuthorDto author) {
        BookDto bookDto = BookDto.builder()
                .isbn("id1")
                .title("con cho nho ngam bo hoa hong")
                .author(author)
                .build();
        return bookDto;
    }
    public static BookEntity getBookA(final AuthorEntity authorEntity) {
        BookEntity bookEntity = BookEntity.builder()
                .isbn("id1")
                .title("con cho nho ngam bo hoa hong")
                .authorEntity(authorEntity)
                .build();
        return bookEntity;
    }
    public static BookEntity getBookB(final AuthorEntity authorEntity) {
        BookEntity bookEntity = BookEntity.builder()
                .isbn("id2")
                .title("dark nhan tam")
                .authorEntity(authorEntity)
                .build();
        return bookEntity;
    }
    public static BookEntity getBookC(final AuthorEntity authorEntity) {
        BookEntity bookEntity = BookEntity.builder()
                .isbn("id3")
                .title("doraemon")
                .authorEntity(authorEntity)
                .build();
        return bookEntity;
    }
}
