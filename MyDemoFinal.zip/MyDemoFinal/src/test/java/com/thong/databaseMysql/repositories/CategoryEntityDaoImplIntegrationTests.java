package com.thong.databaseMysql.repositories;

import com.thong.databaseMysql.TestDataUtil;
import com.thong.databaseMysql.domain.entities.AuthorEntity;
import com.thong.databaseMysql.domain.entities.BookEntity;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class CategoryEntityDaoImplIntegrationTests {



    private  BookRepository underTest;

    @Autowired
    public CategoryEntityDaoImplIntegrationTests(BookRepository bookDao)
    {
        this.underTest = bookDao;
    }
    @Test
    public void testThatBookCanBeCreatedAndRecalled()
    {
        AuthorEntity authorEntity = TestDataUtil.getAuthorA();
        BookEntity bookEntity = TestDataUtil.getBookA(authorEntity);
        underTest.save(bookEntity);
        Optional<BookEntity> result = underTest.findById(bookEntity.getIsbn());
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(bookEntity);
    }
    @Test
    public void testThatBookCanBeFoundMany()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        BookEntity bookEntityA = TestDataUtil.getBookA(authorEntityA);
        BookEntity bookEntityB = TestDataUtil.getBookB(authorEntityA);
        BookEntity bookEntityC = TestDataUtil.getBookC(authorEntityA);

        underTest.save(bookEntityA);
        underTest.save(bookEntityB);
        underTest.save(bookEntityC);
        Iterable<BookEntity> result = underTest.findAll();
        assertThat(result).hasSize(3).containsExactly(bookEntityA, bookEntityB, bookEntityC);
    }
    @Test
    public void testThatBookCanBeUpdated()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        AuthorEntity authorEntityB = TestDataUtil.getAuthorB();
        BookEntity bookEntityA = TestDataUtil.getBookA(authorEntityA);
        underTest.save(bookEntityA);
        bookEntityA.setTitle("Nha gia kim");
        bookEntityA.setAuthorEntity(authorEntityB);
        underTest.save(bookEntityA);
        Optional<BookEntity> result = underTest.findById(bookEntityA.getIsbn());
        assertThat(result).isPresent();
        assertThat(result.get()).isEqualTo(bookEntityA);
    }
    @Test
    public void testThatBookCanBeDeleted()
    {
        AuthorEntity authorEntityA = TestDataUtil.getAuthorA();
        BookEntity bookEntityA = TestDataUtil.getBookA(authorEntityA);
        underTest.save(bookEntityA);
        underTest.delete(bookEntityA);
        Optional<BookEntity> result = underTest.findById(bookEntityA.getIsbn());
        assertThat(result).isEmpty();
    }
}
