package com.thong.databaseMysql;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.thong.databaseMysql.domain.entities.AuthorEntity;
import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class TestJackson {
    @Test
    public void testMarshalling() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        AuthorEntity authorEntity = TestDataUtil.getAuthorA();
        String result = objectMapper.writeValueAsString(authorEntity);
        assertThat(result).isEqualTo("{\"id\":1,\"name\":\"anhnguyen\",\"age\":37}");
    }
    @Test
    public void testUnMarshalling() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        AuthorEntity authorEntity = TestDataUtil.getAuthorA();
        AuthorEntity result = objectMapper.readValue("{\"id\":1,\"name\":\"anhnguyen\",\"age\":37}", AuthorEntity.class);
        assertThat(result).isEqualTo(authorEntity);
    }
}
